package com.weather.core;

public enum DriverType {
	EDGE, CHROME, FIREFOX
}
